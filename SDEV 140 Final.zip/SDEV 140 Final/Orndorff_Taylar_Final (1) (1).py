from tkinter import Tk
from tkinter import *
from tkinter import messagebox
from PIL import ImageTk, Image
# Create a window
pizza = Tk()
pizza.geometry("600x500")
pizza.title("Toni's Pizza Ordering App")

#Allows the user room to input their information
name_label = Label(pizza, text="What is your name?")
name_label.grid(row=0, column=0)

name_entry = Entry(pizza, width=30)
name_entry.grid(row=0, column=1)

address_label = Label(pizza, text="What is your address?")
address_label.grid(row=1, column=0)

address_entry = Entry(pizza, width=30)
address_entry.grid(row=1, column=1)

phone_label = Label(pizza, text="What is your phone number?")
phone_label.grid(row=2, column=0)

phone_entry = Entry(pizza, width=30)
phone_entry.grid(row=2, column=1)


#Create pizza list
my_pizza_list = ["pepperoni","cheese","olives","mushrooms","onions","sausage","peppers","pineapple","ham","bacon"]
#Establishes font, color, size, and the mode of the list
pizza_list = Listbox(pizza, selectmode=MULTIPLE, bg="white", fg="black", height=10, width=20)
pizza_list.grid(row=4, column=1)

for item in my_pizza_list:
  pizza_list.insert(0, item)

#Displays the pizza that the cusotmer choses
def add_pizza():
  result=""
  for item in pizza_list.curselection():
    result = result + str(pizza_list.get(item)) + "\n"

  add_lbl.config(text="Your pizza selection: " +"\n"+ result)

add_lbl = Label(pizza, text="")
add_lbl.grid(row=5, column=1)

#Adds the "Add to order" button
add_button = Button(pizza, text="Add To Order", command=add_pizza)
add_button.grid(row=5, column=0)

#Displays the customer informaiton on the screen
def check():
  text1 = name_entry.get()
  new_lbl = Label(pizza, text="Name: " + text1)
  new_lbl.grid(row=5, column=2)

  text2 = address_entry.get()
  new_lbl2 = Label(pizza, text="Address: " + text2)
  new_lbl2.grid(row=6, column=2)

  text3 = phone_entry.get()
  new_lbl3 = Label(pizza, text="Phone Number: " + text3)
  new_lbl3.grid(row=7, column=2)

#Establishes the check out button
Checkbutton = Button(pizza, text="Check Out", command = check)
Checkbutton.grid(row=6, column=0)

#Allows the user to delete a pizza that they made.
def deleteme():
    pizza_list.delete(0, 8)

del_button = Button(pizza, text = "Delete Pizza", command=deleteme)
del_button.grid(row=7, column=0)

#Allows the user to select drinks from a dropdown menu
drinks = StringVar()
drinks.set("Choose a drink")

drink = OptionMenu(pizza, drinks, "Coke", "Sprite", "Lemonade", "Water")
drink.grid(row=8, column=0)

#Inputs the images on the screen
def load_image(image_path):
  return PhotoImage(file=image_path)
pizza_image = load_image(r"C:\Users\Tony\Downloads\pizza.jpg")
pizza_image_label = Label(pizza, image=pizza_image)
pizza_image_label.grid(row=3, column=6)
soda_image = load_image(r"C:\Users\Tony\Downloads\soda.jpg")
soda_image_label = Label(pizza, image=soda_image)
soda_image_label.grid(row=6, column=6)


#Gives the user an option to exit the program and is prompted.
def exitme():
  answer = messagebox.askyesno("Hi","Are you sure you want to exit?")
  if answer ==1:
    pizza.destroy()
  else:
    return
 

exit_button = Button(pizza, text= "Exit", command=exitme)
exit_button.grid(row = 4, column = 7)

#main loop of the program
pizza.mainloop()
